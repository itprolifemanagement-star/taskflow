import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../theme/app_theme.dart';
import '../../services/message_service.dart';
import '../../models/message.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<AppNotification> _notifications = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await NotificationService.list();
    if (res['success'] == true) {
      _notifications =
          (res['notifications'] as List<dynamic>).map((n) => AppNotification.fromJson(n)).toList();
    }
    setState(() => _loading = false);
  }

  Future<void> _markAllRead() async {
    await NotificationService.markRead();
    _load();
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'task_assigned':
        return Icons.assignment_rounded;
      case 'task_completed':
        return Icons.check_circle_rounded;
      case 'task_updated':
        return Icons.update_rounded;
      case 'new_message':
        return Icons.chat_bubble_rounded;
      case 'comment':
        return Icons.comment_rounded;
      case 'deadline':
        return Icons.alarm_rounded;
      case 'overdue':
        return Icons.warning_rounded;
      case 'announcement':
        return Icons.campaign_rounded;
      default:
        return Icons.notifications_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(onPressed: _markAllRead, child: const Text('Mark all as read')),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _notifications.isEmpty
                ? ListView(
                    children: const [
                      SizedBox(height: 100),
                      Center(child: Text('No notifications yet', style: TextStyle(color: AppColors.textSecondary))),
                    ],
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _notifications.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.border),
                    itemBuilder: (context, i) {
                      final n = _notifications[i];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppColors.primaryLight,
                          child: Icon(_iconFor(n.type), color: AppColors.primary, size: 20),
                        ),
                        title: Text(n.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(n.body ?? ''),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(timeago.format(n.createdAt, locale: 'en_short'),
                                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            if (!n.isRead)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                width: 8, height: 8,
                                decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                              ),
                          ],
                        ),
                        onTap: () async {
                          await NotificationService.markRead(notificationId: n.id);
                          _load();
                        },
                      );
                    },
                  ),
      ),
    );
  }
}
