import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';
import '../../services/task_service.dart';
import '../../services/api_service.dart';

class CreateTaskScreen extends StatefulWidget {
  /// When true, this is a user creating a personal note/task for themself
  /// rather than an admin assigning work to others.
  final bool personalNote;
  const CreateTaskScreen({super.key, this.personalNote = false});

  @override
  State<CreateTaskScreen> createState() => _CreateTaskScreenState();
}

class _CreateTaskScreenState extends State<CreateTaskScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _subtaskController = TextEditingController();
  String _priority = 'Medium';
  DateTime? _dueDate;
  final List<String> _subtasks = [];
  List<Map<String, dynamic>> _users = [];
  final Set<int> _selectedUserIds = {};
  bool _loading = false;
  bool _loadingUsers = true;

  @override
  void initState() {
    super.initState();
    if (!widget.personalNote) _loadUsers();
  }

  Future<void> _loadUsers() async {
    final res = await ApiService.get('users/list.php');
    if (res['success'] == true) {
      setState(() {
        _users = List<Map<String, dynamic>>.from(res['users']);
        _loadingUsers = false;
      });
    } else {
      setState(() => _loadingUsers = false);
    }
  }

  Future<void> _pickDueDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    setState(() {
      _dueDate = DateTime(date.year, date.month, date.day, time?.hour ?? 17, time?.minute ?? 0);
    });
  }

  void _addSubtask() {
    final text = _subtaskController.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _subtasks.add(text);
      _subtaskController.clear();
    });
  }

  Future<void> _submit() async {
    if (_title.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Title is required')));
      return;
    }
    if (!widget.personalNote && _selectedUserIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Assign to at least one user')));
      return;
    }

    setState(() => _loading = true);
    final res = await TaskService.createTask(
      title: _title.text.trim(),
      description: _description.text.trim(),
      priority: _priority,
      dueDate: _dueDate != null ? DateFormat('yyyy-MM-dd HH:mm:ss').format(_dueDate!) : null,
      assigneeIds: _selectedUserIds.toList(),
      subtasks: _subtasks,
    );
    setState(() => _loading = false);
    if (!mounted) return;

    if (res['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? 'Failed to create task')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.personalNote ? 'New Note' : 'New Task')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _label('Task Title'),
            TextField(controller: _title, decoration: const InputDecoration(hintText: 'e.g. Prepare monthly report')),
            const SizedBox(height: 16),
            _label('Description'),
            TextField(
              controller: _description,
              maxLines: 4,
              decoration: const InputDecoration(hintText: 'Add details...'),
            ),
            const SizedBox(height: 16),
            if (!widget.personalNote) ...[
              _label('Assign To'),
              _loadingUsers
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: CircularProgressIndicator())
                  : Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _users.map((u) {
                        final id = int.parse(u['id'].toString());
                        final selected = _selectedUserIds.contains(id);
                        return FilterChip(
                          label: Text(u['full_name']),
                          selected: selected,
                          selectedColor: AppColors.primary,
                          labelStyle: TextStyle(color: selected ? Colors.white : AppColors.textPrimary),
                          onSelected: (v) => setState(() {
                            if (v) {
                              _selectedUserIds.add(id);
                            } else {
                              _selectedUserIds.remove(id);
                            }
                          }),
                        );
                      }).toList(),
                    ),
              const SizedBox(height: 16),
            ],
            _label('Due Date'),
            InkWell(
              onTap: _pickDueDate,
              child: InputDecorator(
                decoration: const InputDecoration(),
                child: Text(
                  _dueDate == null ? 'Select date & time' : DateFormat('MMM d, yyyy • h:mm a').format(_dueDate!),
                  style: TextStyle(color: _dueDate == null ? AppColors.textSecondary : AppColors.textPrimary),
                ),
              ),
            ),
            const SizedBox(height: 16),
            _label('Priority'),
            Wrap(
              spacing: 8,
              children: ['Low', 'Medium', 'High', 'Urgent'].map((p) {
                final selected = _priority == p;
                return ChoiceChip(
                  label: Text(p),
                  selected: selected,
                  selectedColor: AppColors.priorityColor(p),
                  labelStyle: TextStyle(
                      color: selected ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w600),
                  onSelected: (_) => setState(() => _priority = p),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            _label('Subtasks'),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _subtaskController,
                    decoration: const InputDecoration(hintText: 'Add a subtask'),
                    onSubmitted: (_) => _addSubtask(),
                  ),
                ),
                IconButton(onPressed: _addSubtask, icon: const Icon(Icons.add_circle, color: AppColors.primary)),
              ],
            ),
            ..._subtasks.asMap().entries.map((e) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.check_box_outline_blank_rounded, size: 18),
                  title: Text(e.value),
                  trailing: IconButton(
                    icon: const Icon(Icons.close_rounded, size: 18),
                    onPressed: () => setState(() => _subtasks.removeAt(e.key)),
                  ),
                )),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loading ? null : _submit,
              child: _loading
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Text(widget.personalNote ? 'Create Note' : 'Create Task'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _label(String text) =>
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)));
}
