import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../theme/app_theme.dart';
import '../../services/task_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  Map<String, dynamic>? _stats;
  List<dynamic> _byUser = [];
  List<dynamic> _byCategory = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await TaskService.dashboardStats();
    if (res['success'] == true) {
      _stats = res['stats'];
      _byUser = res['progress_by_user'] ?? [];
      _byCategory = res['progress_by_category'] ?? [];
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final total = int.tryParse('${_stats?['total'] ?? 0}') ?? 0;
    final completed = int.tryParse('${_stats?['completed'] ?? 0}') ?? 0;
    final inProgress = int.tryParse('${_stats?['in_progress'] ?? 0}') ?? 0;
    final pending = int.tryParse('${_stats?['pending'] ?? 0}') ?? 0;
    final overdue = int.tryParse('${_stats?['overdue'] ?? 0}') ?? 0;
    final completionPct = total == 0 ? 0.0 : completed / total * 100;

    return Scaffold(
      appBar: AppBar(title: const Text('Reports')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: Column(
                children: [
                  SizedBox(
                    height: 160,
                    width: 160,
                    child: PieChart(
                      PieChartData(
                        sectionsSpace: 3,
                        centerSpaceRadius: 50,
                        sections: [
                          PieChartSectionData(value: completed.toDouble(), color: AppColors.success, showTitle: false),
                          PieChartSectionData(value: inProgress.toDouble(), color: AppColors.info, showTitle: false),
                          PieChartSectionData(value: pending.toDouble(), color: AppColors.warning, showTitle: false),
                          PieChartSectionData(value: overdue.toDouble(), color: AppColors.danger, showTitle: false),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('${completionPct.toStringAsFixed(0)}% Overall Completion',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                _legend('Completed', AppColors.success),
                _legend('In Progress', AppColors.info),
                _legend('Pending', AppColors.warning),
                _legend('Overdue', AppColors.danger),
              ],
            ),
            const SizedBox(height: 28),
            const Text('Progress by User', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 12),
            ..._byUser.map((u) {
              final t = int.tryParse('${u['total']}') ?? 0;
              final c = int.tryParse('${u['completed']}') ?? 0;
              final pct = t == 0 ? 0.0 : c / t;
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(u['full_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('$c/$t', style: const TextStyle(color: AppColors.textSecondary)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                          value: pct, minHeight: 8, backgroundColor: AppColors.border, color: AppColors.primary),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 20),
            const Text('Progress by Category', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 12),
            ..._byCategory.map((c) {
              final t = int.tryParse('${c['total']}') ?? 0;
              final done = int.tryParse('${c['completed']}') ?? 0;
              final pct = t == 0 ? 0.0 : done / t;
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(c['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('$done/$t', style: const TextStyle(color: AppColors.textSecondary)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                          value: pct, minHeight: 8, backgroundColor: AppColors.border, color: AppColors.info),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _legend(String label, Color color) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        ],
      );
}
