import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';

class ActivityLogScreen extends StatefulWidget {
  const ActivityLogScreen({super.key});

  @override
  State<ActivityLogScreen> createState() => _ActivityLogScreenState();
}

class _ActivityLogScreenState extends State<ActivityLogScreen> {
  List<Map<String, dynamic>> _logs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ApiService.get('users/activity_log.php');
    if (res['success'] == true) {
      _logs = List<Map<String, dynamic>>.from(res['logs']);
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activity Log')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                itemCount: _logs.length,
                separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.border),
                itemBuilder: (context, i) {
                  final log = _logs[i];
                  final createdAt = DateTime.tryParse(log['created_at'] ?? '');
                  return ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: AppColors.primaryLight,
                      child: Icon(Icons.history_rounded, color: AppColors.primary, size: 18),
                    ),
                    title: Text('${log['full_name']}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    subtitle: Text(log['action'] ?? ''),
                    trailing: createdAt != null
                        ? Text(timeago.format(createdAt, locale: 'en_short'),
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))
                        : null,
                  );
                },
              ),
      ),
    );
  }
}
