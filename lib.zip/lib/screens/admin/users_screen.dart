import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ApiService.get('users/list.php');
    if (res['success'] == true) {
      _users = List<Map<String, dynamic>>.from(res['users']);
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Users')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: _users.length,
                separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.border),
                itemBuilder: (context, i) {
                  final u = _users[i];
                  final total = u['total_tasks'] ?? 0;
                  final completed = u['completed_tasks'] ?? 0;
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primaryLight,
                      child: Text((u['full_name'] as String).isNotEmpty ? u['full_name'][0] : '?',
                          style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
                    ),
                    title: Text(u['full_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('${u['department'] ?? ''} • ${u['email'] ?? ''}'),
                    trailing: Text('$completed/$total',
                        style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary)),
                  );
                },
              ),
      ),
    );
  }
}
