import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_theme.dart';
import '../../services/auth_provider.dart';
import '../../services/task_service.dart';
import '../../models/task.dart';
import '../../widgets/stat_card.dart';
import '../../widgets/task_card.dart';
import 'task_details_screen.dart';
import 'my_tasks_screen.dart';
import '../shared/notifications_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _stats;
  List<TaskItem> _upcoming = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    final res = await TaskService.dashboardStats();
    if (!mounted) return;
    if (res['success'] == true) {
      setState(() {
        _stats = res['stats'];
        _upcoming = (res['upcoming_tasks'] as List<dynamic>? ?? [])
            .map((t) => TaskItem.fromJson(t))
            .toList();
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final firstName = user?.fullName.split(' ').first ?? 'there';

    return Scaffold(
      appBar: AppBar(
        title: const Text('TaskFlow'),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 110),
                children: [
                  Text('Good day, $firstName 👋', style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 4),
                  const Text("Here’s a quick look at your work.", style: TextStyle(color: AppColors.textSecondary)),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppColors.primary, AppColors.primaryDark],
                      ),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Your progress', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
                              const SizedBox(height: 7),
                              Text(
                                '${_stats?['completed'] ?? 0} completed tasks',
                                style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900),
                              ),
                              const SizedBox(height: 5),
                              const Text('Keep the momentum going.', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 72,
                          height: 72,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              CircularProgressIndicator(
                                value: _completionRate,
                                strokeWidth: 7,
                                backgroundColor: Colors.white24,
                                valueColor: const AlwaysStoppedAnimation(Colors.white),
                              ),
                              Text('${(_completionRate * 100).round()}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.15,
                    children: [
                      StatCard(value: '${_stats?['total'] ?? 0}', label: 'Total Tasks', color: AppColors.primary, icon: Icons.assignment_rounded),
                      StatCard(value: '${_stats?['completed'] ?? 0}', label: 'Completed', color: AppColors.success, icon: Icons.check_circle_rounded),
                      StatCard(value: '${_stats?['in_progress'] ?? 0}', label: 'In Progress', color: AppColors.info, icon: Icons.timelapse_rounded),
                      StatCard(value: '${_stats?['pending'] ?? 0}', label: 'Pending', color: AppColors.warning, icon: Icons.schedule_rounded),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Upcoming deadlines', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                      TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyTasksScreen())), child: const Text('View all')),
                    ],
                  ),
                  const SizedBox(height: 6),
                  if (_upcoming.isEmpty)
                    _emptyState()
                  else
                    ..._upcoming.map((t) => TaskCard(
                      task: t,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => TaskDetailsScreen(taskId: t.id)),
                      ).then((_) => _load()),
                    )),
                ],
              ),
      ),
    );
  }

  double get _completionRate {
    final total = int.tryParse('${_stats?['total'] ?? 0}') ?? 0;
    final completed = int.tryParse('${_stats?['completed'] ?? 0}') ?? 0;
    if (total == 0) return 0;
    return (completed / total).clamp(0, 1);
  }

  Widget _emptyState() => Container(
        padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: const Column(
          children: [
            Icon(Icons.task_alt_rounded, size: 38, color: AppColors.success),
            SizedBox(height: 10),
            Text('You’re all caught up', style: TextStyle(fontWeight: FontWeight.w800)),
            SizedBox(height: 4),
            Text('No upcoming deadlines right now.', style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
          ],
        ),
      );
}
