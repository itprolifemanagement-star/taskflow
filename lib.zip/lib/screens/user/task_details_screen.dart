import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';
import '../../services/task_service.dart';
import '../../services/auth_provider.dart';
import '../../models/task.dart';

class TaskDetailsScreen extends StatefulWidget {
  final int taskId;
  const TaskDetailsScreen({super.key, required this.taskId});

  @override
  State<TaskDetailsScreen> createState() => _TaskDetailsScreenState();
}

class _TaskDetailsScreenState extends State<TaskDetailsScreen> {
  TaskItem? _task;
  bool _loading = true;
  final _commentController = TextEditingController();
  bool _postingComment = false;
  double? _progressDraft;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    final task = await TaskService.getTaskDetails(widget.taskId);
    if (!mounted) return;
    setState(() {
      _task = task;
      _loading = false;
      _progressDraft = task?.progress.toDouble();
    });
  }

  Future<void> _toggleSubtask(Subtask subtask, bool value) async {
    final res = await TaskService.updateTask(widget.taskId, subtaskId: subtask.id, isSubtaskCompleted: value);
    if (!mounted) return;
    if (res['success'] != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Unable to update subtask')),
      );
      return;
    }
    _load();
  }

  Future<void> _updateProgress(int value) async {
    final res = await TaskService.updateTask(widget.taskId, progress: value);
    if (!mounted) return;
    if (res['success'] != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Unable to update progress')),
      );
      return;
    }
    setState(() => _progressDraft = value.toDouble());
    _load();
  }

  Future<void> _updateStatus(String status) async {
    final res = await TaskService.updateTask(widget.taskId, status: status);
    if (!mounted) return;
    if (res['success'] != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Unable to update status')),
      );
      return;
    }
    _load();
  }

  Future<void> _postComment() async {
    final text = _commentController.text.trim();
    if (text.isEmpty) return;
    setState(() => _postingComment = true);
    final res = await TaskService.addComment(widget.taskId, text);
    if (!mounted) return;
    setState(() => _postingComment = false);
    if (res['success'] != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Unable to post comment')),
      );
      return;
    }
    _commentController.clear();
    _load();
  }

  Future<void> _attachFile() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    await TaskService.uploadAttachment(File(picked.path), taskId: widget.taskId);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AuthProvider>().isAdmin;

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_task == null) {
      return const Scaffold(body: Center(child: Text('Task not found')));
    }

    final task = _task!;
    final statusColor = AppColors.statusColor(task.status);

    return Scaffold(
      appBar: AppBar(title: const Text('Task Details')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(task.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _chip(task.priority, AppColors.priorityColor(task.priority)),
                _chip(task.status, statusColor),
                if (task.categoryName != null) _chip(task.categoryName!, AppColors.primary),
              ],
            ),
            const SizedBox(height: 20),
            if (task.description != null && task.description!.isNotEmpty) ...[
              const Text('Description', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(task.description!, style: const TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 20),
            ],
            if (task.dueDate != null) ...[
              Row(
                children: [
                  const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.textSecondary),
                  const SizedBox(width: 6),
                  Text('Due ${DateFormat('MMM d, yyyy • h:mm a').format(task.dueDate!)}',
                      style: const TextStyle(color: AppColors.textSecondary)),
                ],
              ),
              const SizedBox(height: 20),
            ],
            if (task.assignees.isNotEmpty) ...[
              const Text('Assigned To', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: task.assignees
                    .map((a) => Chip(
                          label: Text(a.fullName),
                          backgroundColor: AppColors.primaryLight,
                        ))
                    .toList(),
              ),
              const SizedBox(height: 20),
            ],
            const Text('Progress', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: task.progress / 100,
                      minHeight: 10,
                      backgroundColor: AppColors.border,
                      color: AppColors.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text('${task.progress}%', style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
            if (!isAdmin) ...[
              const SizedBox(height: 8),
              Slider(
                value: (_progressDraft ?? task.progress.toDouble()).clamp(0, 100),
                min: 0,
                max: 100,
                divisions: 20,
                activeColor: AppColors.primary,
                label: '${task.progress}%',
                onChanged: (v) => setState(() => _progressDraft = v),
                onChangeEnd: (v) => _updateProgress(v.round()),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: ['Pending', 'In Progress', 'Completed'].map((s) {
                return ChoiceChip(
                  label: Text(s),
                  selected: task.status == s,
                  selectedColor: AppColors.statusColor(s),
                  labelStyle: TextStyle(
                    color: task.status == s ? Colors.white : AppColors.textPrimary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  onSelected: (_) => _updateStatus(s),
                );
              }).toList(),
            ),
            if (task.subtasks.isNotEmpty) ...[
              const SizedBox(height: 24),
              const Text('Subtasks', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              ...task.subtasks.map((s) => CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: s.isCompleted,
                    activeColor: AppColors.primary,
                    title: Text(s.title,
                        style: TextStyle(
                          decoration: s.isCompleted ? TextDecoration.lineThrough : null,
                          color: s.isCompleted ? AppColors.textSecondary : AppColors.textPrimary,
                        )),
                    onChanged: (v) => _toggleSubtask(s, v ?? false),
                  )),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Attachments', style: TextStyle(fontWeight: FontWeight.w700)),
                TextButton.icon(
                  onPressed: _attachFile,
                  icon: const Icon(Icons.attach_file_rounded, size: 18),
                  label: const Text('Add'),
                ),
              ],
            ),
            if (task.attachments.isEmpty)
              const Text('No attachments yet', style: TextStyle(color: AppColors.textSecondary))
            else
              ...task.attachments.map((a) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.insert_drive_file_rounded, color: AppColors.primary),
                    title: Text(a.fileName),
                  )),
            const SizedBox(height: 24),
            const Text('Comments', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...task.comments.map((c) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: AppColors.primaryLight,
                        child: Text(c.fullName.isNotEmpty ? c.fullName[0] : '?',
                            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(c.fullName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                              const SizedBox(height: 4),
                              Text(c.comment),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentController,
                    decoration: const InputDecoration(hintText: 'Add a comment...'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _postingComment ? null : _postComment,
                  icon: const Icon(Icons.send_rounded, color: AppColors.primary),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
      );
}
