import 'dart:io';
import 'api_service.dart';
import '../models/task.dart';

class TaskService {
  static Future<List<TaskItem>> listTasks({String? status, String? search}) async {
    final query = <String, String>{};
    if (status != null) query['status'] = status;
    if (search != null && search.isNotEmpty) query['search'] = search;

    final res = await ApiService.get('tasks/list.php', query: query);
    if (res['success'] != true) return [];
    return (res['tasks'] as List<dynamic>).map((t) => TaskItem.fromJson(t)).toList();
  }

  static Future<TaskItem?> getTaskDetails(int taskId) async {
    final res = await ApiService.get('tasks/details.php', query: {'id': '$taskId'});
    if (res['success'] != true || res['task'] == null) return null;
    return TaskItem.fromJson(res['task']);
  }

  static Future<Map<String, dynamic>> createTask({
    required String title,
    String? description,
    int? categoryId,
    required String priority,
    String? dueDate,
    String? reminderAt,
    List<int> assigneeIds = const [],
    List<String> subtasks = const [],
  }) {
    return ApiService.post('tasks/create.php', {
      'title': title,
      'description': description,
      'category_id': categoryId,
      'priority': priority,
      'due_date': dueDate,
      'reminder_at': reminderAt,
      'assignee_ids': assigneeIds,
      'subtasks': subtasks,
    });
  }

  static Future<Map<String, dynamic>> updateTask(
    int taskId, {
    int? progress,
    String? status,
    int? subtaskId,
    bool? isSubtaskCompleted,
    Map<String, dynamic>? adminFields,
  }) {
    final body = <String, dynamic>{'task_id': taskId};
    if (progress != null) body['progress'] = progress;
    if (status != null) body['status'] = status;
    if (subtaskId != null) {
      body['subtask_id'] = subtaskId;
      body['is_completed'] = isSubtaskCompleted ?? false;
    }
    if (adminFields != null) body.addAll(adminFields);
    return ApiService.post('tasks/update.php', body);
  }

  static Future<Map<String, dynamic>> addComment(int taskId, String comment) {
    return ApiService.post('tasks/add_comment.php', {'task_id': taskId, 'comment': comment});
  }

  static Future<Map<String, dynamic>> uploadAttachment(File file, {int? taskId}) {
    return ApiService.uploadFile(
      'tasks/upload_attachment.php',
      file,
      fields: taskId != null ? {'task_id': '$taskId'} : {},
    );
  }

  static Future<Map<String, dynamic>> dashboardStats() {
    return ApiService.get('tasks/dashboard_stats.php');
  }
}
